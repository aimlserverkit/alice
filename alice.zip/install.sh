cd local
cp -r -f * /usr/local/bin
cd ..
rm -r -f local
cd /usr/local/bin
chmod -R 765 *
sed -i 's/exit 0//g' /etc/rc
echo 'cd /usr/local/bin' >> /etc/rc
echo 'nohup sh deploy.sh &' >> /etc/rc
echo 'exit 0' >> /etc/rc
rm install.sh
reboot

