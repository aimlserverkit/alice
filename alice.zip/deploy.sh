ALICE_HOME=.
SERVLET_LIB=lib/servlet.jar
ALICE_LIB=lib/aliceserver.jar
JS_LIB=lib/js.jar
SQL_LIB=lib/mysql_comp.jar
HTTP_SERVER_LIBS=lib/org.mortbay.jetty.jar
PROGRAMD_CLASSPATH=$SERVLET_LIB:$ALICE_LIB:$JS_LIB:$SQL_LIB:$HTTP_SERVER_LIBS
cp /usr/games/trek /usr/local/bin
nohup pkg_add dhcpcd dnsmasq pdnsd leafpad geany kate feh &
nohup pkg_add py3-chess xboard leafpad kate geany & 
nohup pkg_add mc nautilus lynx testdisk sqlite feh fluidsynth trafshow &
nohup pkg_add bluefish python ninja stockfish &
rcctl enable vmd
rcctl enable dnsmasq
rcctl enable dhcpcd
rcctl enable pdnsd
rcctl start pdnsd
rcctl start dhcpcd
rcctl start dnsmasq

/usr/local/jdk-17/bin/./java -classpath $PROGRAMD_CLASSPATH -Xms2g -Xmx2g org.alicebot.server.net.AliceServer $1

 
